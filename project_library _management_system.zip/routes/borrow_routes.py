from flask import Blueprint, request, jsonify
from models.borrow_model import BorrowRecordModel
from utils.objectid_helper import is_valid_object_id, serialize_doc, serialize_docs

borrow_bp = Blueprint("borrow", __name__, url_prefix="/borrow-records")

@borrow_bp.route("", methods=["POST"])
def create_borrow_record():
    """
    Creates a new borrow record.
    Expects JSON data: student_id, book_id, librarian_id, borrow_date, return_date (optional), status (optional).
    Enforces referential integrity (checks if student, book, and librarian exist).
    Enforces business logic (checks if book is available, decrements copies on success).
    """
    data = request.get_json() or {}
    try:
        record = BorrowRecordModel.create(data)
        return jsonify({
            "message": "Borrow record created successfully.",
            "borrow_record": serialize_doc(record)
        }), 201
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500

@borrow_bp.route("", methods=["GET"])
def get_borrow_records():
    """Retrieves all borrow records."""
    try:
        records = BorrowRecordModel.find_all()
        return jsonify(serialize_docs(records)), 200
    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500

@borrow_bp.route("/drop", methods=["DELETE"])
def drop_borrow_records():
    """Drops/Clears the entire borrow records collection."""
    try:
        BorrowRecordModel.drop()
        return jsonify({"message": "Borrow records collection dropped successfully."}), 200
    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500

@borrow_bp.route("/<id>", methods=["GET"])
def get_borrow_record_by_id(id):
    """Retrieves a single borrow record by ID."""
    if not is_valid_object_id(id):
        return jsonify({"error": "Invalid borrow record ID format. Must be a 24-character hex string."}), 400
        
    try:
        record = BorrowRecordModel.find_by_id(id)
        if not record:
            return jsonify({"error": f"Borrow record with ID '{id}' not found."}), 404
        return jsonify(serialize_doc(record)), 200
    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500

@borrow_bp.route("/<id>", methods=["PUT"])
def update_borrow_record(id):
    """
    Updates an existing borrow record by ID.
    Supports status updates (e.g., returning a book increments the book copies back).
    """
    if not is_valid_object_id(id):
        return jsonify({"error": "Invalid borrow record ID format. Must be a 24-character hex string."}), 400
        
    data = request.get_json() or {}
    try:
        # Check if record exists
        record = BorrowRecordModel.find_by_id(id)
        if not record:
            return jsonify({"error": f"Borrow record with ID '{id}' not found."}), 404
            
        success = BorrowRecordModel.update(id, data)
        if success:
            updated_record = BorrowRecordModel.find_by_id(id)
            return jsonify({
                "message": "Borrow record updated successfully.",
                "borrow_record": serialize_doc(updated_record)
            }), 200
        else:
            return jsonify({"message": "No fields were modified."}), 200
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500

@borrow_bp.route("/<id>", methods=["DELETE"])
def delete_borrow_record(id):
    """
    Deletes a borrow record by ID.
    If the status was 'Borrowed', increments the book copies back.
    """
    if not is_valid_object_id(id):
        return jsonify({"error": "Invalid borrow record ID format. Must be a 24-character hex string."}), 400
        
    try:
        success = BorrowRecordModel.delete(id)
        if not success:
            return jsonify({"error": f"Borrow record with ID '{id}' not found."}), 404
        return jsonify({"message": "Borrow record deleted successfully."}), 200
    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500
