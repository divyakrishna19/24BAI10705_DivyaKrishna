from bson import ObjectId
from database.db import get_db

def get_student_collection():
    """Returns the students collection."""
    db = get_db()
    db.students.create_index("email", unique=True)
    db.students.create_index("library_card_number", unique=True)
    return db.students

def validate_student_data(data, is_update=False):
    """
    Validates student data.
    Returns (is_valid, error_message).
    """
    required_fields = ["name", "email", "department", "year", "library_card_number"]
    
    if not is_update:
        for field in required_fields:
            if field not in data or not str(data[field]).strip():
                return False, f"Field '{field}' is required and cannot be empty."
    else:
        if not data:
            return False, "At least one field must be provided for update."
        for field in data:
            if field in required_fields and not str(data[field]).strip():
                return False, f"Field '{field}' cannot be empty."
                
    return True, None

class StudentModel:
    @staticmethod
    def create(data):
        """Inserts a new student into the database."""
        is_valid, err = validate_student_data(data)
        if not is_valid:
            raise ValueError(err)
            
        students = get_student_collection()
        
        if students.find_one({"email": data["email"]}):
            raise ValueError("Student with this email already exists.")
        if students.find_one({"library_card_number": data["library_card_number"]}):
            raise ValueError("Student with this library card number already exists.")
            
        student_doc = {
            "name": data["name"].strip(),
            "email": data["email"].strip(),
            "department": data["department"].strip(),
            "year": data["year"],
            "library_card_number": data["library_card_number"].strip()
        }
        
        result = students.insert_one(student_doc)
        student_doc["_id"] = result.inserted_id
        return student_doc

    @staticmethod
    def find_all():
        """Retrieves all students."""
        students = get_student_collection()
        return list(students.find())

    @staticmethod
    def find_by_id(student_id):
        """Retrieves a student by their MongoDB ObjectId."""
        students = get_student_collection()
        return students.find_one({"_id": ObjectId(student_id)})

    @staticmethod
    def update(student_id, data):
        """Updates a student's information by ID."""
        is_valid, err = validate_student_data(data, is_update=True)
        if not is_valid:
            raise ValueError(err)
            
        students = get_student_collection()
        
        if "email" in data:
            existing = students.find_one({"email": data["email"]})
            if existing and str(existing["_id"]) != str(student_id):
                raise ValueError("Student with this email already exists.")
                
        if "library_card_number" in data:
            existing = students.find_one({"library_card_number": data["library_card_number"]})
            if existing and str(existing["_id"]) != str(student_id):
                raise ValueError("Student with this library card number already exists.")
        
        update_fields = {}
        for field in ["name", "email", "department", "year", "library_card_number"]:
            if field in data:
                update_fields[field] = data[field].strip() if isinstance(data[field], str) else data[field]
                
        result = students.update_one({"_id": ObjectId(student_id)}, {"$set": update_fields})
        return result.modified_count > 0 or result.matched_count > 0

    @staticmethod
    def delete(student_id):
        """Deletes a student by ID."""
        students = get_student_collection()
        result = students.delete_one({"_id": ObjectId(student_id)})
        return result.deleted_count > 0

    @staticmethod
    def drop():
        """Drops the students collection."""
        students = get_student_collection()
        students.drop()
        return True
