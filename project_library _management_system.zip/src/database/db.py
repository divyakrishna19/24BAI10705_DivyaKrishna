from pymongo import MongoClient
from config import Config

# Global database client and database references
client = None
db = None

def init_db(app=None):
    """
    Initializes the MongoDB connection using the configured MONGO_URI and DB_NAME.
    Can be called with a Flask app instance to load configurations dynamically.
    """
    global client, db
    
    if app:
        mongo_uri = app.config.get("MONGO_URI", Config.MONGO_URI)
        db_name = app.config.get("DB_NAME", Config.DB_NAME)
    else:
        mongo_uri = Config.MONGO_URI
        db_name = Config.DB_NAME

    client = MongoClient(mongo_uri)
    db = client[db_name]
    
    # Optional: Verify connection
    try:
        client.admin.command('ismaster')
        print(f"[*] MongoDB connected successfully to database: '{db_name}'")
    except Exception as e:
        print(f"[!] MongoDB connection error: {e}")
        
    return db

def get_db():
    """
    Returns the database instance. Initializes if it doesn't exist.
    """
    global db
    if db is None:
        init_db()
    return db
