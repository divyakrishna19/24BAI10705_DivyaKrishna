import os
import sys

# Add the directory containing this file (src/) to the python path
# to ensure imports work correctly regardless of how/where it is executed from.
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from flask import Flask, jsonify
from config import Config
from database.db import init_db

# Import Blueprints
from routes.student_routes import student_bp
from routes.librarian_routes import librarian_bp
from routes.book_routes import book_bp
from routes.borrow_routes import borrow_bp

def create_app():
    """
    Application factory pattern to configure and initialize the Flask application.
    """
    app = Flask(__name__)
    
    # Load configuration
    app.config.from_object(Config)
    
    # Initialize the database connection
    init_db(app)
    
    # Register blueprints
    app.register_blueprint(student_bp)
    app.register_blueprint(librarian_bp)
    app.register_blueprint(book_bp)
    app.register_blueprint(borrow_bp)
    
    # Root API Endpoint
    @app.route("/", methods=["GET"])
    def index():
        return jsonify({
            "project": "Library Management System API",
            "version": "1.0.0",
            "status": "Running",
            "endpoints": {
                "students": "/students",
                "librarians": "/librarians",
                "books": "/books",
                "borrow_records": "/borrow-records"
            }
        }), 200

    # Global Error Handlers for JSON responses
    @app.errorhandler(404)
    def resource_not_found(e):
        return jsonify({"error": "Resource not found."}), 404

    @app.errorhandler(400)
    def bad_request(e):
        return jsonify({"error": "Bad request. Please check your JSON payload or parameters."}), 400

    @app.errorhandler(500)
    def internal_server_error(e):
        return jsonify({"error": "An internal server error occurred."}), 500

    return app

if __name__ == "__main__":
    app = create_app()
    print(f"[*] Starting Library Management System Flask Server on port {app.config.get('PORT')}...")
    app.run(
        host="0.0.0.0",
        port=app.config.get("PORT"),
        debug=app.config.get("DEBUG")
    )
