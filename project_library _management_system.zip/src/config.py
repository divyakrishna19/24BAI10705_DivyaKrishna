import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

class Config:
    """Base configuration settings for the Library Management System."""
    MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017/library_db")
    PORT = int(os.getenv("PORT", 5000))
    DEBUG = os.getenv("DEBUG", "True").lower() in ("true", "1", "t")
    DB_NAME = os.getenv("DB_NAME", "library_db")
