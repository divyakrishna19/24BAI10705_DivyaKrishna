from flask import Blueprint, request, jsonify
from models.librarian_model import LibrarianModel
from utils.objectid_helper import is_valid_object_id, serialize_doc, serialize_docs

librarian_bp = Blueprint("librarian", __name__, url_prefix="/librarians")

@librarian_bp.route("", methods=["POST"])
def create_librarian():
    """
    Creates a new librarian record.
    Expects JSON data: name, email, employee_id, shift.
    """
    data = request.get_json() or {}
    try:
        librarian = LibrarianModel.create(data)
        return jsonify({
            "message": "Librarian created successfully.",
            "librarian": serialize_doc(librarian)
        }), 201
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500

@librarian_bp.route("", methods=["GET"])
def get_librarians():
    """Retrieves all librarian records."""
    try:
        librarians = LibrarianModel.find_all()
        return jsonify(serialize_docs(librarians)), 200
    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500

@librarian_bp.route("/drop", methods=["DELETE"])
def drop_librarians():
    """Drops/Clears the entire librarians collection."""
    try:
        LibrarianModel.drop()
        return jsonify({"message": "Librarians collection dropped successfully."}), 200
    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500

@librarian_bp.route("/<id>", methods=["GET"])
def get_librarian_by_id(id):
    """Retrieves a single librarian record by ID."""
    if not is_valid_object_id(id):
        return jsonify({"error": "Invalid librarian ID format. Must be a 24-character hex string."}), 400
        
    try:
        librarian = LibrarianModel.find_by_id(id)
        if not librarian:
            return jsonify({"error": f"Librarian with ID '{id}' not found."}), 404
        return jsonify(serialize_doc(librarian)), 200
    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500

@librarian_bp.route("/<id>", methods=["PUT"])
def update_librarian(id):
    """Updates an existing librarian record by ID."""
    if not is_valid_object_id(id):
        return jsonify({"error": "Invalid librarian ID format. Must be a 24-character hex string."}), 400
        
    data = request.get_json() or {}
    try:
        librarian = LibrarianModel.find_by_id(id)
        if not librarian:
            return jsonify({"error": f"Librarian with ID '{id}' not found."}), 404
            
        success = LibrarianModel.update(id, data)
        if success:
            updated_librarian = LibrarianModel.find_by_id(id)
            return jsonify({
                "message": "Librarian updated successfully.",
                "librarian": serialize_doc(updated_librarian)
            }), 200
        else:
            return jsonify({"message": "No fields were modified."}), 200
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500

@librarian_bp.route("/<id>", methods=["DELETE"])
def delete_librarian(id):
    """Deletes a librarian record by ID."""
    if not is_valid_object_id(id):
        return jsonify({"error": "Invalid librarian ID format. Must be a 24-character hex string."}), 400
        
    try:
        success = LibrarianModel.delete(id)
        if not success:
            return jsonify({"error": f"Librarian with ID '{id}' not found."}), 404
        return jsonify({"message": "Librarian deleted successfully."}), 200
    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500
