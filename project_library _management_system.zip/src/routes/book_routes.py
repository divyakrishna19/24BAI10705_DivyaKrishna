from flask import Blueprint, request, jsonify
from models.book_model import BookModel
from utils.objectid_helper import is_valid_object_id, serialize_doc, serialize_docs

book_bp = Blueprint("book", __name__, url_prefix="/books")

@book_bp.route("", methods=["POST"])
def create_book():
    """
    Creates a new book record.
    Expects JSON data: title, author, isbn, category, available_copies.
    """
    data = request.get_json() or {}
    try:
        book = BookModel.create(data)
        return jsonify({
            "message": "Book created successfully.",
            "book": serialize_doc(book)
        }), 201
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500

@book_bp.route("", methods=["GET"])
def get_books():
    """Retrieves all book records."""
    try:
        books = BookModel.find_all()
        return jsonify(serialize_docs(books)), 200
    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500

@book_bp.route("/drop", methods=["DELETE"])
def drop_books():
    """Drops/Clears the entire books collection."""
    try:
        BookModel.drop()
        return jsonify({"message": "Books collection dropped successfully."}), 200
    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500

@book_bp.route("/<id>", methods=["GET"])
def get_book_by_id(id):
    """Retrieves a single book record by ID."""
    if not is_valid_object_id(id):
        return jsonify({"error": "Invalid book ID format. Must be a 24-character hex string."}), 400
        
    try:
        book = BookModel.find_by_id(id)
        if not book:
            return jsonify({"error": f"Book with ID '{id}' not found."}), 404
        return jsonify(serialize_doc(book)), 200
    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500

@book_bp.route("/<id>", methods=["PUT"])
def update_book(id):
    """Updates an existing book record by ID."""
    if not is_valid_object_id(id):
        return jsonify({"error": "Invalid book ID format. Must be a 24-character hex string."}), 400
        
    data = request.get_json() or {}
    try:
        book = BookModel.find_by_id(id)
        if not book:
            return jsonify({"error": f"Book with ID '{id}' not found."}), 404
            
        success = BookModel.update(id, data)
        if success:
            updated_book = BookModel.find_by_id(id)
            return jsonify({
                "message": "Book updated successfully.",
                "book": serialize_doc(updated_book)
            }), 200
        else:
            return jsonify({"message": "No fields were modified."}), 200
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500

@book_bp.route("/<id>", methods=["DELETE"])
def delete_book(id):
    """Deletes a book record by ID."""
    if not is_valid_object_id(id):
        return jsonify({"error": "Invalid book ID format. Must be a 24-character hex string."}), 400
        
    try:
        success = BookModel.delete(id)
        if not success:
            return jsonify({"error": f"Book with ID '{id}' not found."}), 404
        return jsonify({"message": "Book deleted successfully."}), 200
    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500
