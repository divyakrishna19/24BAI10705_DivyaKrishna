from flask import Blueprint, request, jsonify
from models.student_model import StudentModel
from utils.objectid_helper import is_valid_object_id, serialize_doc, serialize_docs

student_bp = Blueprint("student", __name__, url_prefix="/students")

@student_bp.route("", methods=["POST"])
def create_student():
    """
    Creates a new student record.
    Expects JSON data: name, email, department, year, library_card_number.
    """
    data = request.get_json() or {}
    try:
        student = StudentModel.create(data)
        return jsonify({
            "message": "Student created successfully.",
            "student": serialize_doc(student)
        }), 201
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500

@student_bp.route("", methods=["GET"])
def get_students():
    """Retrieves all student records."""
    try:
        students = StudentModel.find_all()
        return jsonify(serialize_docs(students)), 200
    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500

@student_bp.route("/drop", methods=["DELETE"])
def drop_students():
    """Drops/Clears the entire students collection."""
    try:
        StudentModel.drop()
        return jsonify({"message": "Students collection dropped successfully."}), 200
    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500

@student_bp.route("/<id>", methods=["GET"])
def get_student_by_id(id):
    """Retrieves a single student record by their ID."""
    if not is_valid_object_id(id):
        return jsonify({"error": "Invalid student ID format. Must be a 24-character hex string."}), 400
        
    try:
        student = StudentModel.find_by_id(id)
        if not student:
            return jsonify({"error": f"Student with ID '{id}' not found."}), 404
        return jsonify(serialize_doc(student)), 200
    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500

@student_bp.route("/<id>", methods=["PUT"])
def update_student(id):
    """Updates an existing student record by ID."""
    if not is_valid_object_id(id):
        return jsonify({"error": "Invalid student ID format. Must be a 24-character hex string."}), 400
        
    data = request.get_json() or {}
    try:
        student = StudentModel.find_by_id(id)
        if not student:
            return jsonify({"error": f"Student with ID '{id}' not found."}), 404
            
        success = StudentModel.update(id, data)
        if success:
            updated_student = StudentModel.find_by_id(id)
            return jsonify({
                "message": "Student updated successfully.",
                "student": serialize_doc(updated_student)
            }), 200
        else:
            return jsonify({"message": "No fields were modified."}), 200
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500

@student_bp.route("/<id>", methods=["DELETE"])
def delete_student(id):
    """Deletes a student record by ID."""
    if not is_valid_object_id(id):
        return jsonify({"error": "Invalid student ID format. Must be a 24-character hex string."}), 400
        
    try:
        success = StudentModel.delete(id)
        if not success:
            return jsonify({"error": f"Student with ID '{id}' not found."}), 404
        return jsonify({"message": "Student deleted successfully."}), 200
    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500
