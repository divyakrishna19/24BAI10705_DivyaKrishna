# PowerShell script to run the Library Management System API server

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $scriptDir

Write-Host "=========================================" -ForegroundColor Cyan
Write-Host "Starting Library Management System API..." -ForegroundColor Cyan
Write-Host "=========================================" -ForegroundColor Cyan

if (-not (Test-Path "venv")) {
    Write-Host "[!] Virtual environment 'venv' not found. Installing dependencies first..." -ForegroundColor Yellow
    . .\download_dependencies.ps1
}

$activateScript = ".\venv\Scripts\Activate.ps1"
if (Test-Path $activateScript) {
    . $activateScript
    Write-Host "[*] Launching API server..." -ForegroundColor Green
    python src/app.py
} else {
    Write-Host "[!] Error: Activation script not found at $activateScript." -ForegroundColor Red
}
