# PowerShell script to download and install python dependencies inside a virtual environment

Write-Host "=========================================" -ForegroundColor Cyan
Write-Host "Setting up Library Management System..." -ForegroundColor Cyan
Write-Host "=========================================" -ForegroundColor Cyan

# 1. Check if Python is installed
try {
    $pythonVersion = python --version 2>&1
    Write-Host "[*] Found Python: $pythonVersion" -ForegroundColor Green
} catch {
    Write-Host "[!] Error: Python is not installed or not in your system PATH." -ForegroundColor Red
    Write-Host "Please install Python from https://www.python.org/ before continuing." -ForegroundColor Yellow
    Exit
}

# 2. Check and create virtual environment
if (-not (Test-Path "venv")) {
    Write-Host "[*] Creating virtual environment 'venv'..." -ForegroundColor Yellow
    python -m venv venv
    if ($LASTEXITCODE -ne 0) {
        Write-Host "[!] Error: Failed to create virtual environment." -ForegroundColor Red
        Exit
    }
    Write-Host "[*] Virtual environment created successfully." -ForegroundColor Green
} else {
    Write-Host "[*] Virtual environment 'venv' already exists." -ForegroundColor Green
}

# 3. Activate virtual environment and install requirements
Write-Host "[*] Activating virtual environment..." -ForegroundColor Yellow
$activateScript = ".\venv\Scripts\Activate.ps1"
if (Test-Path $activateScript) {
    # Activate virtual environment
    . $activateScript
    
    Write-Host "[*] Upgrading pip..." -ForegroundColor Yellow
    python -m pip install --upgrade pip
    
    Write-Host "[*] Installing packages from requirements.txt..." -ForegroundColor Yellow
    pip install -r requirements.txt
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "[*] Dependencies installed successfully!" -ForegroundColor Green
    } else {
        Write-Host "[!] Error: Failed to install some dependencies." -ForegroundColor Red
    }
} else {
    Write-Host "[!] Error: Activation script not found at $activateScript." -ForegroundColor Red
}

Write-Host "=========================================" -ForegroundColor Cyan
Write-Host "Setup Completed! You can now run the app." -ForegroundColor Cyan
Write-Host "=========================================" -ForegroundColor Cyan
