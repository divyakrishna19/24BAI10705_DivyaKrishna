import os
import sys

# Reference src/config.py directly for backward compatibility
src_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "src")
if src_path not in sys.path:
    sys.path.insert(0, src_path)

from src.config import Config
