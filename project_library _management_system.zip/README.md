# Library Management System (API-based Backend)

A complete, beginner-friendly RESTful API for a **Library Management System** built with **Flask** and **MongoDB** (using PyMongo). This project features a clean, organized folder layout with helper scripts to automate environment configuration and project execution.

---

## 🎯 Project Objective

To build a robust and clean API backend to manage a library's daily operations. The system implements full CRUD (Create, Read, Update, Delete) capabilities across four core entities while maintaining relational mapping and database consistency (e.g., decrementing book copies when a book is borrowed and incrementing them when returned).

---

## 🛠️ Tech Stack

- **Backend Framework**: Flask (Python)
- **Database**: MongoDB (via PyMongo client)
- **Environment Management**: Python-dotenv
- **API Testing**: Postman (Pre-configured collection included)

---

## 📂 Project Structure

```text
library-management-system/
│
├── README.md                      # Project documentation
├── requirements.txt               # Project dependencies
├── .gitignore                     # Files excluded from git
├── download_dependencies.ps1      # PowerShell script to install Python & venv dependencies
├── run.ps1                        # PowerShell script to run the application
├── run_api.ps1                    # PowerShell script to run the API server
│
├── screenshots/                   # Directory for project screenshots
│   └── .gitkeep
│
├── lib/                           # Placeholder for external libraries/venv links
│   └── .gitkeep
│
├── app.py                         # Root wrapper (redirects execution to src/app.py)
├── config.py                      # Root wrapper configuration helper
├── .env                           # Root configuration environment variables
│
└── src/                           # All source code
    ├── app.py                     # Main application entry point & Blueprint registration
    ├── config.py                  # Environmental configuration loader
    ├── .env                       # Local environment variables
    │
    ├── database/
    │   └── db.py                  # PyMongo client initialization & connection logic
    │
    ├── models/
    │   ├── student_model.py       # Student validations & database queries
    │   ├── librarian_model.py     # Librarian validations & database queries
    │   ├── book_model.py          # Book validations & database queries
    │   └── borrow_model.py        # Borrow Record validations & relational business logic
    │
    ├── routes/
    │   ├── student_routes.py      # Flask routes for Student operations
    │   ├── librarian_routes.py    # Flask routes for Librarian operations
    │   ├── book_routes.py         # Flask routes for Book operations
    │   └── borrow_routes.py       # Flask routes for Borrow Record operations
    │
    └── utils/
        └── objectid_helper.py     # Utilities for ObjectId validation and JSON serialization
```

---

## 🔗 Entity Relationship Explanation

Although MongoDB is a NoSQL (document-based) database, we implement relational links using BSON `ObjectId` references inside documents:

1. **One-to-One (Student ↔ Library Card)**
   - Enforced by making the `library_card_number` field a **unique index** inside the `students` collection. This guarantees that one student is associated with exactly one library card.
2. **One-to-Many (Student ↔ BorrowRecords)**
   - A single student can have multiple borrow records over time. This is represented by storing the Student's `_id` as `student_id` in the `borrow_records` collection.
3. **Many-to-One (BorrowRecords ↔ Librarian)**
   - Many borrow records are handled and approved by a single librarian. Represented by storing the Librarian's `_id` as `librarian_id` in the `borrow_records` collection.
4. **Many-to-Many (Student ↔ Book)**
   - Many students can borrow many different books over time. This is modeled using the `borrow_records` collection as a junction table containing both `student_id` and `book_id` references.

---

## 🚀 Business Logic Rules

- **Borrowing a Book**:
  1. Validates that the referenced Student, Book, and Librarian exist in the database.
  2. Verifies if the book's `available_copies` is greater than 0. If it is 0, the API returns a `400 Bad Request` explaining that the book is currently unavailable.
  3. Automatically decrements the book's `available_copies` by 1 upon a successful borrow.
- **Returning a Book**:
  1. Updates the borrow record status to `Returned` and logs the `return_date`.
  2. Automatically increments the book's `available_copies` by 1.
- **Deleting a Borrow Record**:
  1. If the deleted record had a status of `Borrowed` (i.e. not yet returned), it automatically increments `available_copies` by 1 to maintain database consistency.

---

## 📊 API Endpoints

### 1. Students (`/students`)
| Method | Endpoint | Description | Payloads / Params |
| :--- | :--- | :--- | :--- |
| **POST** | `/students` | Create a new student | JSON payload containing student details |
| **GET** | `/students` | Get all students | None |
| **GET** | `/students/<id>` | Get student by ID | Path parameter: `id` (24-char hex string) |
| **PUT** | `/students/<id>` | Update student details | JSON payload containing fields to update |
| **DELETE** | `/students/<id>` | Delete student | Path parameter: `id` |
| **DELETE** | `/students/drop` | Drop students collection | None |

### 2. Librarians (`/librarians`)
| Method | Endpoint | Description | Payloads / Params |
| :--- | :--- | :--- | :--- |
| **POST** | `/librarians` | Create a new librarian | JSON payload containing librarian details |
| **GET** | `/librarians` | Get all librarians | None |
| **GET** | `/librarians/<id>` | Get librarian by ID | Path parameter: `id` |
| **PUT** | `/librarians/<id>` | Update librarian details | JSON payload containing fields to update |
| **DELETE** | `/librarians/<id>` | Delete librarian | Path parameter: `id` |
| **DELETE** | `/librarians/drop` | Drop librarians collection | None |

### 3. Books (`/books`)
| Method | Endpoint | Description | Payloads / Params |
| :--- | :--- | :--- | :--- |
| **POST** | `/books` | Create a new book | JSON payload containing book details |
| **GET** | `/books` | Get all books | None |
| **GET** | `/books/<id>` | Get book by ID | Path parameter: `id` |
| **PUT** | `/books/<id>` | Update book details | JSON payload containing fields to update |
| **DELETE** | `/books/<id>` | Delete book | Path parameter: `id` |
| **DELETE** | `/books/drop` | Drop books collection | None |

### 4. Borrow Records (`/borrow-records`)
| Method | Endpoint | Description | Payloads / Params |
| :--- | :--- | :--- | :--- |
| **POST** | `/borrow-records` | Create a borrow record | JSON containing `student_id`, `book_id`, `librarian_id`, etc. |
| **GET** | `/borrow-records` | Get all borrow records | None |
| **GET** | `/borrow-records/<id>` | Get borrow record by ID | Path parameter: `id` |
| **PUT** | `/borrow-records/<id>` | Update record (e.g. Return book) | JSON payload containing fields to update |
| **DELETE** | `/borrow-records/<id>` | Delete record | Path parameter: `id` |
| **DELETE** | `/borrow-records/drop` | Drop borrow records collection | None |

---

## 💻 Easy Setup & Run (Windows PowerShell)

We have provided automated scripts to make setting up and running the project simple for evaluators.

### 1. Download Dependencies
Right-click `download_dependencies.ps1` and select **Run with PowerShell**, or execute this in your terminal:
```powershell
.\download_dependencies.ps1
```
*This script automatically checks if Python is installed, configures a virtual environment (`venv`), upgrades pip, and installs all libraries listed in `requirements.txt`.*

### 2. Run the App
Right-click `run.ps1` (or `run_api.ps1`) and select **Run with PowerShell**, or execute:
```powershell
.\run.ps1
```
*This will activate the virtual environment and launch the Flask API server.*

---

## 🛠️ Manual Installation & Setup (Alternative)

### Prerequisites
- Python 3.8 or higher installed.
- MongoDB Server running locally on port `27017` (or configured remotely).

### Steps
1. Navigate to the project directory:
   ```bash
   cd library-management-system
   ```
2. Create a virtual environment:
   ```bash
   python -m venv venv
   ```
3. Activate the virtual environment:
   - **Windows**:
     ```powershell
     .\venv\Scripts\activate
     ```
   - **macOS/Linux**:
     ```bash
     source venv/bin/activate
     ```
4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
5. Run the server:
   ```bash
   python src/app.py
   ```

---

## 🧪 Testing with Postman

We have provided a fully configured Postman collection to make testing all API routes simple and fast.

1. **Import the Collection**:
   - Open Postman, click **Import** in the top left, and select the file: `Library_Management_System.postman_collection.json` from the project root.
2. **Review Variables**:
   - Under the collection settings, navigate to the **Variables** tab.
   - The default `base_url` is set to `http://127.0.0.1:5000`. You can change this if your server is running elsewhere.
3. **Execute Requests**:
   - Create a Student, Librarian, and Book first.
   - Extract their `_id` values from the JSON responses.
   - Save those IDs in the collection variables: `student_id`, `librarian_id`, and `book_id`.
   - Send the **Create Borrow Record** request. It uses these variables automatically!
   - Try updating the Borrow Record's status to `Returned` to verify that the book's `available_copies` increments back up!
