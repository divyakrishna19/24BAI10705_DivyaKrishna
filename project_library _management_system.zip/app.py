import os
import sys

# Add the src/ directory to the path so that imports align
src_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "src")
if src_path not in sys.path:
    sys.path.insert(0, src_path)

from src.app import create_app

if __name__ == "__main__":
    app = create_app()
    print("[*] Redirected execution to src/app.py successfully.")
    app.run(
        host="0.0.0.0",
        port=app.config.get("PORT"),
        debug=app.config.get("DEBUG")
    )
