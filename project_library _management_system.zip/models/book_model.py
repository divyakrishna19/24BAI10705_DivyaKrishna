from bson import ObjectId
from database.db import get_db

def get_book_collection():
    """Returns the books collection."""
    db = get_db()
    # Create unique index on ISBN to prevent duplicates
    db.books.create_index("isbn", unique=True)
    return db.books

def validate_book_data(data, is_update=False):
    """
    Validates book data.
    Returns (is_valid, error_message).
    """
    required_fields = ["title", "author", "isbn", "category", "available_copies"]
    
    if not is_update:
        # Check all fields for creation
        for field in required_fields:
            if field not in data:
                return False, f"Field '{field}' is required."
            if field != "available_copies" and not str(data[field]).strip():
                return False, f"Field '{field}' cannot be empty."
        
        # Ensure available_copies is a valid integer >= 0
        try:
            copies = int(data["available_copies"])
            if copies < 0:
                return False, "available_copies must be greater than or equal to 0."
        except (ValueError, TypeError):
            return False, "available_copies must be a valid integer."
    else:
        # For updates, check only provided fields
        if not data:
            return False, "At least one field must be provided for update."
        for field in data:
            if field in required_fields:
                if field != "available_copies" and not str(data[field]).strip():
                    return False, f"Field '{field}' cannot be empty."
                if field == "available_copies":
                    try:
                        copies = int(data["available_copies"])
                        if copies < 0:
                            return False, "available_copies must be greater than or equal to 0."
                    except (ValueError, TypeError):
                        return False, "available_copies must be a valid integer."
                        
    return True, None

class BookModel:
    @staticmethod
    def create(data):
        """Inserts a new book into the database."""
        is_valid, err = validate_book_data(data)
        if not is_valid:
            raise ValueError(err)
            
        books = get_book_collection()
        
        # Check uniqueness constraint
        if books.find_one({"isbn": data["isbn"]}):
            raise ValueError("Book with this ISBN already exists.")
            
        book_doc = {
            "title": data["title"].strip(),
            "author": data["author"].strip(),
            "isbn": data["isbn"].strip(),
            "category": data["category"].strip(),
            "available_copies": int(data["available_copies"])
        }
        
        result = books.insert_one(book_doc)
        book_doc["_id"] = result.inserted_id
        return book_doc

    @staticmethod
    def find_all():
        """Retrieves all books."""
        books = get_book_collection()
        return list(books.find())

    @staticmethod
    def find_by_id(book_id):
        """Retrieves a book by ID."""
        books = get_book_collection()
        return books.find_one({"_id": ObjectId(book_id)})

    @staticmethod
    def update(book_id, data):
        """Updates a book's details by ID."""
        is_valid, err = validate_book_data(data, is_update=True)
        if not is_valid:
            raise ValueError(err)
            
        books = get_book_collection()
        
        # Check uniqueness if ISBN is updated
        if "isbn" in data:
            existing = books.find_one({"isbn": data["isbn"]})
            if existing and str(existing["_id"]) != str(book_id):
                raise ValueError("Book with this ISBN already exists.")
        
        update_fields = {}
        for field in ["title", "author", "isbn", "category"]:
            if field in data:
                update_fields[field] = data[field].strip()
        if "available_copies" in data:
            update_fields["available_copies"] = int(data["available_copies"])
                
        result = books.update_one({"_id": ObjectId(book_id)}, {"$set": update_fields})
        return result.modified_count > 0 or result.matched_count > 0

    @staticmethod
    def delete(book_id):
        """Deletes a book by ID."""
        books = get_book_collection()
        result = books.delete_one({"_id": ObjectId(book_id)})
        return result.deleted_count > 0

    @staticmethod
    def drop():
        """Drops the books collection."""
        books = get_book_collection()
        books.drop()
        return True
