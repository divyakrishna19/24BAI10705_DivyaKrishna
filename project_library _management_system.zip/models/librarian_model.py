from bson import ObjectId
from database.db import get_db

def get_librarian_collection():
    """Returns the librarians collection."""
    db = get_db()
    # Create unique indexes to prevent duplicates
    db.librarians.create_index("email", unique=True)
    db.librarians.create_index("employee_id", unique=True)
    return db.librarians

def validate_librarian_data(data, is_update=False):
    """
    Validates librarian data.
    Returns (is_valid, error_message).
    """
    required_fields = ["name", "email", "employee_id", "shift"]
    
    if not is_update:
        # Check all fields for creation
        for field in required_fields:
            if field not in data or not str(data[field]).strip():
                return False, f"Field '{field}' is required and cannot be empty."
    else:
        # For updates, ensure at least one field is provided and non-empty
        if not data:
            return False, "At least one field must be provided for update."
        for field in data:
            if field in required_fields and not str(data[field]).strip():
                return False, f"Field '{field}' cannot be empty."
                
    return True, None

class LibrarianModel:
    @staticmethod
    def create(data):
        """Inserts a new librarian into the database."""
        is_valid, err = validate_librarian_data(data)
        if not is_valid:
            raise ValueError(err)
            
        librarians = get_librarian_collection()
        
        # Check uniqueness constraints
        if librarians.find_one({"email": data["email"]}):
            raise ValueError("Librarian with this email already exists.")
        if librarians.find_one({"employee_id": data["employee_id"]}):
            raise ValueError("Librarian with this employee ID already exists.")
            
        librarian_doc = {
            "name": data["name"].strip(),
            "email": data["email"].strip(),
            "employee_id": data["employee_id"].strip(),
            "shift": data["shift"].strip()
        }
        
        result = librarians.insert_one(librarian_doc)
        librarian_doc["_id"] = result.inserted_id
        return librarian_doc

    @staticmethod
    def find_all():
        """Retrieves all librarians."""
        librarians = get_librarian_collection()
        return list(librarians.find())

    @staticmethod
    def find_by_id(librarian_id):
        """Retrieves a librarian by ID."""
        librarians = get_librarian_collection()
        return librarians.find_one({"_id": ObjectId(librarian_id)})

    @staticmethod
    def update(librarian_id, data):
        """Updates a librarian's information by ID."""
        is_valid, err = validate_librarian_data(data, is_update=True)
        if not is_valid:
            raise ValueError(err)
            
        librarians = get_librarian_collection()
        
        # Check uniqueness constraints if updated
        if "email" in data:
            existing = librarians.find_one({"email": data["email"]})
            if existing and str(existing["_id"]) != str(librarian_id):
                raise ValueError("Librarian with this email already exists.")
                
        if "employee_id" in data:
            existing = librarians.find_one({"employee_id": data["employee_id"]})
            if existing and str(existing["_id"]) != str(librarian_id):
                raise ValueError("Librarian with this employee ID already exists.")
        
        update_fields = {}
        for field in ["name", "email", "employee_id", "shift"]:
            if field in data:
                update_fields[field] = data[field].strip()
                
        result = librarians.update_one({"_id": ObjectId(librarian_id)}, {"$set": update_fields})
        return result.modified_count > 0 or result.matched_count > 0

    @staticmethod
    def delete(librarian_id):
        """Deletes a librarian by ID."""
        librarians = get_librarian_collection()
        result = librarians.delete_one({"_id": ObjectId(librarian_id)})
        return result.deleted_count > 0

    @staticmethod
    def drop():
        """Drops the librarians collection."""
        librarians = get_librarian_collection()
        librarians.drop()
        return True
