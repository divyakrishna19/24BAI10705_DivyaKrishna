from bson import ObjectId
from datetime import datetime
from database.db import get_db
from utils.objectid_helper import is_valid_object_id

def get_borrow_collection():
    """Returns the borrowrecords collection."""
    return get_db().borrow_records

def validate_borrow_data(data, is_update=False):
    """
    Validates borrow record data.
    Returns (is_valid, error_message).
    """
    required_ids = ["student_id", "book_id", "librarian_id"]
    
    if not is_update:
        # Check all required references
        for field in required_ids:
            if field not in data or not str(data[field]).strip():
                return False, f"Field '{field}' is required."
            if not is_valid_object_id(data[field]):
                return False, f"Field '{field}' must be a valid 24-character hexadecimal ObjectId."
                
        if "borrow_date" not in data or not str(data["borrow_date"]).strip():
            return False, "Field 'borrow_date' is required."
        
        # Simple date validation (YYYY-MM-DD)
        try:
            datetime.strptime(data["borrow_date"].strip(), "%Y-%m-%d")
        except ValueError:
            return False, "borrow_date must be in YYYY-MM-DD format."
            
        # Optional return_date validation
        if "return_date" in data and data["return_date"]:
            try:
                datetime.strptime(data["return_date"].strip(), "%Y-%m-%d")
            except ValueError:
                return False, "return_date must be in YYYY-MM-DD format."
                
        # Status validation
        status = data.get("status", "Borrowed").strip()
        if status not in ["Borrowed", "Returned"]:
            return False, "status must be either 'Borrowed' or 'Returned'."
    else:
        # For updates
        if not data:
            return False, "At least one field must be provided for update."
            
        for field in required_ids:
            if field in data:
                if not str(data[field]).strip() or not is_valid_object_id(data[field]):
                    return False, f"Field '{field}' must be a valid ObjectId."
                    
        if "borrow_date" in data:
            try:
                datetime.strptime(data["borrow_date"].strip(), "%Y-%m-%d")
            except ValueError:
                return False, "borrow_date must be in YYYY-MM-DD format."
                
        if "return_date" in data and data["return_date"]:
            try:
                datetime.strptime(data["return_date"].strip(), "%Y-%m-%d")
            except ValueError:
                return False, "return_date must be in YYYY-MM-DD format."
                
        if "status" in data:
            if data["status"] not in ["Borrowed", "Returned"]:
                return False, "status must be either 'Borrowed' or 'Returned'."
                
    return True, None

class BorrowRecordModel:
    @staticmethod
    def create(data):
        """
        Creates a new borrow record.
        Validates relationships, checks book copies, and decrements book copies on success.
        """
        is_valid, err = validate_borrow_data(data)
        if not is_valid:
            raise ValueError(err)
            
        db = get_db()
        student_id = ObjectId(data["student_id"].strip())
        book_id = ObjectId(data["book_id"].strip())
        librarian_id = ObjectId(data["librarian_id"].strip())
        
        # 1. Verify student exists
        if not db.students.find_one({"_id": student_id}):
            raise ValueError("Student reference not found.")
            
        # 2. Verify librarian exists
        if not db.librarians.find_one({"_id": librarian_id}):
            raise ValueError("Librarian reference not found.")
            
        # 3. Verify book exists and has copies
        book = db.books.find_one({"_id": book_id})
        if not book:
            raise ValueError("Book reference not found.")
            
        if book.get("available_copies", 0) <= 0:
            raise ValueError("Book is currently unavailable (0 copies remaining).")
            
        # 4. Decrement book copies
        db.books.update_one({"_id": book_id}, {"$inc": {"available_copies": -1}})
        
        # 5. Insert record
        status = data.get("status", "Borrowed").strip()
        borrow_doc = {
            "student_id": student_id,
            "book_id": book_id,
            "librarian_id": librarian_id,
            "borrow_date": data["borrow_date"].strip(),
            "return_date": data.get("return_date", "").strip() or None,
            "status": status
        }
        
        # If status is initially "Returned", we increment the copies back (though unusual, let's be safe)
        if status == "Returned":
            db.books.update_one({"_id": book_id}, {"$inc": {"available_copies": 1}})
            
        borrows = get_borrow_collection()
        result = borrows.insert_one(borrow_doc)
        borrow_doc["_id"] = result.inserted_id
        return borrow_doc

    @staticmethod
    def find_all():
        """Retrieves all borrow records."""
        borrows = get_borrow_collection()
        return list(borrows.find())

    @staticmethod
    def find_by_id(borrow_id):
        """Retrieves a borrow record by ID."""
        borrows = get_borrow_collection()
        return borrows.find_one({"_id": ObjectId(borrow_id)})

    @staticmethod
    def update(borrow_id, data):
        """
        Updates a borrow record.
        Manages book copies if the borrowing status changes (e.g. Returned).
        """
        is_valid, err = validate_borrow_data(data, is_update=True)
        if not is_valid:
            raise ValueError(err)
            
        db = get_db()
        borrows = get_borrow_collection()
        
        # Find the existing record to see if status is changing
        existing_record = borrows.find_one({"_id": ObjectId(borrow_id)})
        if not existing_record:
            raise ValueError("Borrow record not found.")
            
        # Verify references if they are being updated
        if "student_id" in data:
            if not db.students.find_one({"_id": ObjectId(data["student_id"])}):
                raise ValueError("Student reference not found.")
        if "librarian_id" in data:
            if not db.librarians.find_one({"_id": ObjectId(data["librarian_id"])}):
                raise ValueError("Librarian reference not found.")
        if "book_id" in data:
            new_book_id = ObjectId(data["book_id"])
            if not db.books.find_one({"_id": new_book_id}):
                raise ValueError("Book reference not found.")
                
        # Handle book copy adjustments if book is changing or status is changing
        old_book_id = existing_record["book_id"]
        old_status = existing_record["status"]
        
        new_book_id = ObjectId(data["book_id"].strip()) if "book_id" in data else old_book_id
        new_status = data.get("status", old_status).strip()
        
        # Build update fields
        update_fields = {}
        for field in ["borrow_date"]:
            if field in data:
                update_fields[field] = data[field].strip()
        if "return_date" in data:
            update_fields["return_date"] = data["return_date"].strip() if data["return_date"] else None
        if "student_id" in data:
            update_fields["student_id"] = ObjectId(data["student_id"].strip())
        if "librarian_id" in data:
            update_fields["librarian_id"] = ObjectId(data["librarian_id"].strip())
        if "book_id" in data:
            update_fields["book_id"] = new_book_id
        if "status" in data:
            update_fields["status"] = new_status

        # If book changed:
        # 1. Return copy to old book (if old status was Borrowed)
        # 2. Take copy from new book (if new status is Borrowed)
        if str(old_book_id) != str(new_book_id):
            if old_status == "Borrowed":
                db.books.update_one({"_id": old_book_id}, {"$inc": {"available_copies": 1}})
            if new_status == "Borrowed":
                # Check copies of new book
                new_book = db.books.find_one({"_id": new_book_id})
                if new_book.get("available_copies", 0) <= 0:
                    # Rollback previous change if needed, but we raise error before database changes are committed
                    raise ValueError("New book has no available copies.")
                db.books.update_one({"_id": new_book_id}, {"$inc": {"available_copies": -1}})
        else:
            # Same book, check status change
            if old_status == "Borrowed" and new_status == "Returned":
                # Book returned
                db.books.update_one({"_id": old_book_id}, {"$inc": {"available_copies": 1}})
                # Automatically set return_date to today if not provided
                if "return_date" not in update_fields or not update_fields["return_date"]:
                    update_fields["return_date"] = datetime.today().strftime("%Y-%m-%d")
            elif old_status == "Returned" and new_status == "Borrowed":
                # Re-borrowed? Check copies
                book = db.books.find_one({"_id": old_book_id})
                if book.get("available_copies", 0) <= 0:
                    raise ValueError("Book has no available copies.")
                db.books.update_one({"_id": old_book_id}, {"$inc": {"available_copies": -1}})
                update_fields["return_date"] = None

        result = borrows.update_one({"_id": ObjectId(borrow_id)}, {"$set": update_fields})
        return result.modified_count > 0 or result.matched_count > 0

    @staticmethod
    def delete(borrow_id):
        """
        Deletes a borrow record.
        If deleted record was 'Borrowed', increments the book copies back.
        """
        db = get_db()
        borrows = get_borrow_collection()
        
        record = borrows.find_one({"_id": ObjectId(borrow_id)})
        if not record:
            return False
            
        # If it was borrowed, return the book copy
        if record.get("status") == "Borrowed":
            db.books.update_one({"_id": record["book_id"]}, {"$inc": {"available_copies": 1}})
            
        result = borrows.delete_one({"_id": ObjectId(borrow_id)})
        return result.deleted_count > 0

    @staticmethod
    def drop():
        """Drops the borrow records collection."""
        borrows = get_borrow_collection()
        borrows.drop()
        return True
