from bson import ObjectId
from bson.errors import InvalidId

def is_valid_object_id(id_str):
    """
    Checks if a string is a valid MongoDB ObjectId.
    Returns True if valid, False otherwise.
    """
    try:
        ObjectId(id_str)
        return True
    except (InvalidId, TypeError):
        return False

def to_object_id(id_str):
    """
    Converts a string representation of an ID to a BSON ObjectId.
    Returns the ObjectId if successful, or None if the ID is invalid.
    """
    if not id_str:
        return None
    try:
        return ObjectId(id_str)
    except (InvalidId, TypeError):
        return None

def serialize_doc(doc):
    """
    Recursively converts BSON ObjectIds in a MongoDB document to strings 
    so the document can be serialized into a clean JSON response.
    """
    if doc is None:
        return None
    
    serialized = {}
    for key, value in doc.items():
        if isinstance(value, ObjectId):
            serialized[key] = str(value)
        elif isinstance(value, list):
            # Handle list of items (e.g., list of ObjectIds or sub-documents)
            serialized[key] = [
                str(item) if isinstance(item, ObjectId) else (serialize_doc(item) if isinstance(item, dict) else item)
                for item in value
            ]
        elif isinstance(value, dict):
            serialized[key] = serialize_doc(value)
        else:
            serialized[key] = value
            
    return serialized

def serialize_docs(docs):
    """
    Converts a list/cursor of MongoDB documents into a list of 
    JSON-serializable dictionaries.
    """
    return [serialize_doc(doc) for doc in docs]
