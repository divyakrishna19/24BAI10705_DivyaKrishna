# PowerShell script to run the Library Management System application

# Change directory to the script's folder location
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $scriptDir

Write-Host "=========================================" -ForegroundColor Cyan
Write-Host "Starting Library Management System..." -ForegroundColor Cyan
Write-Host "=========================================" -ForegroundColor Cyan

# 1. Check if virtual environment exists, if not, set up dependencies first
if (-not (Test-Path "venv")) {
    Write-Host "[!] Virtual environment 'venv' not found. Installing dependencies first..." -ForegroundColor Yellow
    . .\download_dependencies.ps1
}

# 2. Activate virtual environment and run the Flask API
$activateScript = ".\venv\Scripts\Activate.ps1"
if (Test-Path $activateScript) {
    Write-Host "[*] Activating virtual environment..." -ForegroundColor Yellow
    . $activateScript
    
    Write-Host "[*] Launching API server..." -ForegroundColor Green
    python src/app.py
} else {
    Write-Host "[!] Error: Activation script not found at $activateScript." -ForegroundColor Red
}
